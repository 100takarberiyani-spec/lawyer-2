# Advocate Ashwani Gautam — Website Demo

Open `index.html` in a browser.

Included:
- Responsive premium legal-professional design
- BCI disclaimer acknowledgement modal
- About, practice areas, approach, FAQ and contact sections
- Click-to-call and WhatsApp links
- Instagram link supplied by the client
- Google Maps button + embedded map
- Consultation form with validation and WhatsApp handoff
- Mobile responsive navigation
- No invented education, enrollment number, experience or testimonials

Known social media account:
Instagram: https://www.instagram.com/advocate_ashwani_gautam/

Before production:
1. Replace the silhouette in the hero with the advocate's approved professional photograph.
2. Add verified education, enrollment number and years of practice.
3. Connect the consultation form to a secure backend/email/CRM.
4. Have the final legal disclaimer and professional copy reviewed before publication.
